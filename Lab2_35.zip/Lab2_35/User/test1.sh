#!/bin/bash

while true
do
./leds set caps on;
sleep 0.5;
./leds set caps off;
sleep 0.5;
done


