#ifndef TESTS_FILESYS_BASE_SYN_READ_H
#define TESTS_FILESYS_BASE_SYN_READ_H

#define BUF_SIZE 1024
static const char file_name[] = "data";

#endif /* tests/filesys/base/syn-read.h */
